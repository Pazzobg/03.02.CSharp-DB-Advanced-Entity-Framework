﻿namespace FastFood.DataProcessor
{
    using System;
    using System.IO;
    using FastFood.Data;
    using System.Linq;
    using FastFood.Models.Enums;
    using Microsoft.EntityFrameworkCore;

    public class Serializer
    {
        public static string ExportOrdersByEmployee(FastFoodDbContext context, string employeeName, string orderType)
        {
            var employee = context.Employees.FirstOrDefault(e => e.Name == employeeName);
            var type = Enum.Parse<OrderType>(orderType);

            var orders = context.Orders
                .Include(o => o.Employee)
                .Include(o => o.OrderItems)
                .Where(o => o.Type == type && o.Employee.Name == employeeName)
                
                .ToArray();


            //    var totalOrderPrice = orders
            //        .Select(oi => new
            //        {
            //            OrderPrice = oi.OrderItems.Item.Price * oi.Quantity
            //        })
            //        .ToArray();
            //foreach (var order in orders)
            //{

            //}


            return null;
        }

        public static string ExportCategoryStatistics(FastFoodDbContext context, string categoriesString)
        {
            throw new NotImplementedException();
        }
    }
}