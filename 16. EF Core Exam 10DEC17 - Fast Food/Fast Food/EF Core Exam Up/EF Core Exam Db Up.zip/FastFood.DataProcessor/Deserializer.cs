﻿namespace FastFood.DataProcessor
{
    using System;
    using FastFood.Data;
    using FastFood.DataProcessor.Dto.Import;
    using Newtonsoft.Json;
    using System.Text;
    using System.Collections.Generic;
    using FastFood.Models;
    using System.ComponentModel.DataAnnotations;
    using System.Linq;

    public static class Deserializer
    {
        private const string FailureMessage = "Invalid data format.";
        private const string SuccessMessage = "Record {0} successfully imported.";

        public static string ImportEmployees(FastFoodDbContext context, string jsonString)
        {
            var employees = JsonConvert.DeserializeObject<EmployeeDto[]>(jsonString);

            var sb = new StringBuilder();
            var validEmployees = new List<Employee>();

            foreach (var emplDto in employees)
            {
                if (!IsValid(emplDto))
                {
                    sb.AppendLine(FailureMessage);
                    continue;
                }

                bool positionExists = context.Positions.Any(p => p.Name == emplDto.Position);
                if (!positionExists)
                {
                    context.Positions.Add(new Position
                    {
                        Name = emplDto.Position
                    });

                    context.SaveChanges();
                }

                var employee = new Employee
                {
                    Name = emplDto.Name,
                    Age = emplDto.Age,
                    PositionId = context.Positions.FirstOrDefault(p => p.Name == emplDto.Position).Id
                };

                validEmployees.Add(employee);
                sb.AppendLine(string.Format(SuccessMessage, emplDto.Name));
            }

            context.Employees.AddRange(validEmployees);
            context.SaveChanges();

            var result = sb.ToString().TrimEnd();
            return result;
        }

        //public static string ImportItems(FastFoodDbContext context, string jsonString)
        //{
        //    var items = JsonConvert.DeserializeObject<ItemDto[]>(jsonString);

        //    var sb = new StringBuilder();
        //    var validEmployees = new List<Employee>();

        //    foreach (var emplDto in employees)

        //}

        public static string ImportOrders(FastFoodDbContext context, string xmlString)
        {
            throw new NotImplementedException();
        }

        private static bool IsValid(object obj)
        {
            var validationContext = new System.ComponentModel.DataAnnotations.ValidationContext(obj);
            var validationResult = new List<ValidationResult>();
            var isValid = Validator.TryValidateObject(obj, validationContext, validationResult, true);

            return isValid;
        }
    }
}