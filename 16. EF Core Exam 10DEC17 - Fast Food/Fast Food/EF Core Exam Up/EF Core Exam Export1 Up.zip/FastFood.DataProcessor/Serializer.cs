﻿namespace FastFood.DataProcessor
{
    using System;
    using System.IO;
    using FastFood.Data;
    using System.Linq;
    using FastFood.Models.Enums;
    using Microsoft.EntityFrameworkCore;
    using FastFood.DataProcessor.Dto.Export;
    using System.Collections.Generic;
    using Newtonsoft.Json;

    public class Serializer
    {
        public static string ExportOrdersByEmployee(FastFoodDbContext context, string employeeName, string orderType)
        {
            var employee = context.Employees.FirstOrDefault(e => e.Name == employeeName);
            var type = Enum.Parse<OrderType>(orderType);
            var totalMoneyMade = 0m;

            var orders = context.Orders
                .Include(o => o.Employee)
                .Include(o => o.OrderItems)
                .Where(o => o.Type == type && o.Employee.Name == employeeName)
                .ToArray();

            var dtosToExport = new List<OrderDto>();

            foreach (var order in orders)
            {
                var dto = new OrderDto
                {
                    Customer = order.Customer
                };

                var orderPrice = 0m;

                foreach (var oi in order.OrderItems)
                {
                    orderPrice += oi.Item.Price * oi.Quantity;
                    dto.Items.Add(new ItemDto
                    {
                        Name = oi.Item.Name,
                        Price = oi.Item.Price,
                        Quantity = oi.Quantity
                    });
                }

                dto.TotalPrice = orderPrice;
                totalMoneyMade += orderPrice;

                dtosToExport.Add(dto);
            }

            var orderedDtos = dtosToExport
                .OrderByDescending(d => d.TotalPrice)
                .ThenByDescending(d => d.Items.Count)
                .ToList();

            var result = new
            {
                Name = employeeName, 
                Orders = orderedDtos.Select(d => new
                {
                    Customer = d.Customer, 
                    Items = d.Items.Select( i => new
                    {
                        Name = i.Name, 
                        Price = i.Price, 
                        Quantity = i.Quantity
                    }).ToArray(), 
                    TotalPrice = d.TotalPrice
                }).ToArray(), 
                TotalMade = totalMoneyMade                
            };

            string jsonString = JsonConvert.SerializeObject(result, Formatting.Indented);
            return jsonString;
        }

        public static string ExportCategoryStatistics(FastFoodDbContext context, string categoriesString)
        {
            throw new NotImplementedException();
        }
    }
}