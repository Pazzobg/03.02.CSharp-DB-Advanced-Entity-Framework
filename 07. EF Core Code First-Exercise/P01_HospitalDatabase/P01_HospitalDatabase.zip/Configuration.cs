﻿namespace P01_HospitalDatabase
{
    public class Configuration
    {
        public const string ConnectionString = @"Server=.;Database=Hospital;Integrated Security=True";
    }
}
